/* Programa em C++ que ajuda Pizza a criar
uma imagem com faixas verticais distintas
que evite as restricoes de cores estabelecida
por ela*/

#include <iostream>

//funcao que compara duas palavras caractere por caractere
int compara(char palavra_1[], char palavra_2[], int posicao) {

    //palavras diferentes
    if (palavra_1[posicao] != palavra_2[posicao]) {
        return 0;
    }

    //palavras iguais
    if (palavra_1[posicao] == '\0') {
        return 1;
    }

    //comparacao ate o ultimo caractere
    return compara(palavra_1, palavra_2, posicao + 1);
}


//funcao que conta a quantidade de pinturas
void contar_pinturas(int posicao, int quantidade_cores, int pintura[], int cor_usada[], int incompatibilidade[][12], int &quantidade_pinturas) {

    //pintura valida
    if (posicao == quantidade_cores) {
        quantidade_pinturas++;
        return;
    }

    //testa todas as cores
    for (int cor = 0; cor < quantidade_cores; cor++) {

        //verifica se a cor ainda nao foi usada
        if (cor_usada[cor] == 0) {
            
            //verifica se a cor pode ser colocada depois da cor anterior
            if (posicao == 0 || incompatibilidade[pintura[posicao - 1]][cor] == 0) {
                
                //coloca a cor na posicao atual da pintura
                pintura[posicao] = cor;
                
                //marca a cor como usada
                cor_usada[cor] = 1;
                
                //chama a funcao para preencher a proxima posicao
                contar_pinturas(posicao + 1, quantidade_cores, pintura, cor_usada, incompatibilidade, quantidade_pinturas);
                
                //desmarca a cor para testes futuros
                cor_usada[cor] = 0;
            }
        }
    }
}


//funcao que encontra uma pintura valida
int encontrar_favorita(int posicao, int quantidade_cores, int pintura[], int cor_usada[], int incompatibilidade[][12]) {

    //pintura completa
    if (posicao == quantidade_cores) {
        return 1;
    }

    //testa todas as cores para a posicao atual
    for (int cor = 0; cor < quantidade_cores; cor++) {

        //verifica se a cor ainda nao foi usada
        if (cor_usada[cor] == 0) {
            
            //verifica se a cor pode ser colocada depois da cor anterior
            if (posicao == 0 || incompatibilidade[pintura[posicao - 1]][cor] == 0) {
                
                //coloca a cor na pintura
                pintura[posicao] = cor;
                
                //marca a cor como usada
                cor_usada[cor] = 1;
                
                //tenta preencher a proxima posicao
                if (encontrar_favorita(posicao + 1, quantidade_cores, pintura, cor_usada, incompatibilidade)) {
                    return 1;
                }
                
                //libera a cor para tentar outra
                cor_usada[cor] = 0;
            }
        }
    }

    return 0;
}


int main() {

    //leitura dos casos de teste
    int casos;
    std::cin >> casos;

    //processa os casos de teste
    while (casos--) {
        
        //quantidade de faixas/cores
        int quantidade_faixas;
        std::cin >> quantidade_faixas;
        
        //vetor que guarda os nomes das cores
        char cores[12][21];
        
        //leitura das cores
        for (int i = 0; i < quantidade_faixas; i++) {
            std::cin >> cores[i];
        }
        
        //variavel que guarda os conflitos de cores
        int incompatibilidade[12][12] = {};
        
        //leitura da quantidade de pares de cores
        int quantidade_pares;
        std::cin >> quantidade_pares;
        
        //leitura dos pares de cores que sao incompativeis
        for (int i = 0; i < quantidade_pares; i++) {
            
            //variaveis que guardam os nomes das duas cores
            char primeira_cor[21];
            char segunda_cor[21];
            
            //leitura das duas cores
            std::cin >> primeira_cor >> segunda_cor;
            
            //variaveis que guardam os indices das cores
            int indice_primeira = -1;
            int indice_segunda = -1;
            
            //procura o indice das duas cores no vetor de cores
            for (int j = 0; j < quantidade_faixas; j++) {
                
                //verifica se encontrou a primeira cor
                if (compara(cores[j], primeira_cor, 0)) {
                    indice_primeira = j;
                }
                
                //verifica se encontrou a segunda cor
                if (compara(cores[j], segunda_cor, 0)) {
                    indice_segunda = j;
                }
            }
            
            //verifica se as duas cores foram encontradas
            if (indice_primeira != -1 && indice_segunda != -1) {
                
                //marca incompatibilidade entre primeira e segunda
                incompatibilidade[indice_primeira][indice_segunda] = 1;
                
                //marca incompatibilidade entre segunda e primeira
                incompatibilidade[indice_segunda][indice_primeira] = 1;
            }
        }
        
        //vetor que guarda a ordem das cores na pintura
        int pintura[12];
        
        //vetor que verifica quais cores ja foram usadas
        int cor_usada[12] = {};
        
        //variavel que guarda a quantidade de pinturas possiveis
        int quantidade_pinturas = 0;
        
        //conta todas as pinturas possiveis
        contar_pinturas(0, quantidade_faixas, pintura, cor_usada, incompatibilidade, quantidade_pinturas);
        
        //zera o vetor de cores usadas
        for (int i = 0; i < quantidade_faixas; i++) {
            cor_usada[i] = 0;
        }
        
        //encontra uma pintura valida
        encontrar_favorita(0, quantidade_faixas, pintura, cor_usada, incompatibilidade);
        
        //mostra a quantidade de pinturas encontradas
        std::cout << quantidade_pinturas << "\n";
        
        //mostra as cores da pintura encontrada
        for (int i = 0; i < quantidade_faixas; i++) {
            
            //coloca um espaco entre as cores
            if (i > 0) {
                std::cout << " ";
            }
            
            //mostra o nome da cor
            std::cout << cores[pintura[i]];
        }
        
        //pula para a proxima linha
        std::cout << "\n";
    }

    return 0;
}