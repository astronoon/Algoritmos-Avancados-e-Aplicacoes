/* Programa em C++ que calcula a quantidade
de ovos que podem ser colocados em uma
tigela no microondas para ferverem ao
mesmo tempo sem correr nenhum risco*/

#include <iostream>

int main() {
    
    //leitura dos casos de teste
    int casos;
    std::cin >> casos;

    //processa os casos teste
    for (int caso_atual = 1; caso_atual <= casos; caso_atual++) {
        
        //leitura das variaveis
        int total_ovos, max_ovos, peso_max_tigela;
        std::cin >> total_ovos >> max_ovos >> peso_max_tigela;
        
        //vetor que guarda o peso de cada ovo
        int ovos[30];
        
        //leitura dos pesos dos ovos
        for (int j = 0; j < total_ovos; j++) {
            std::cin >> ovos[j];
        }
        
        //quantidade de ovos escolhidos
        int quantidade = 0;
        
        //peso total dos ovos escolhidos
        int peso_total = 0;
        
        //analisamos os ovos do menor peso para o maior peso
        for (int peso = 1; peso <= 10; peso++) {
            //procura todos os ovos que possuem esse peso
            for (int i = 0; i < total_ovos; i++) {
                //ovo precisa ter o peso procurado, n passar do max da tigela e n passar do peso total
                if (ovos[i] == peso && quantidade < max_ovos && peso_total + peso <= peso_max_tigela) {
                    //adiciona o peso do ovo
                    peso_total += peso;
                    
                    //aumenta a quantidade de ovos escolhidos
                    quantidade++;
                    
                    //marca o ovo como escolhido
                    ovos[i] = 0;
                }
            }
        }
        
        //saida do programa
        std::cout << "Caso " << caso_atual << ": " << quantidade << std::endl;
    }

    return 0;
}