/*programa em c++ que usa programacao
dinamica para determinar o trem mais
longo que pode ser formado*/

#include <iostream>

//limite de vagoes 
const int limite_maximo_vagoes = 2005;

int main() {
    //variavel dos casos teste 
    int numero_casos_teste;

    //le a quantidade de casos de teste 
    std::cin >> numero_casos_teste;

    //resolve todos os casos de teste 
    while (numero_casos_teste--) {
        int numero_vagoes;
        
        //le a quantidade de vagoes 
        std::cin >> numero_vagoes;
        
        //vetores relacionados aos vagoes e tamanho 
        int pesos_vagoes[limite_maximo_vagoes];
        int maior_crescente[limite_maximo_vagoes];
        int maior_decrescente[limite_maximo_vagoes];
        
        //le os pesos dos vagoes 
        for (int indice_atual = 0; indice_atual < numero_vagoes; indice_atual++) {
            std::cin >> pesos_vagoes[indice_atual];
        }
        
        int maior_crescente_geral = 0;
        int maior_decrescente_geral = 0;
        
        //calcula as maiores sequencias a partir de cada vagao 
        for (int vagao_atual = numero_vagoes - 1; vagao_atual >= 0; vagao_atual--) {
            maior_crescente[vagao_atual] = 1;
            maior_decrescente[vagao_atual] = 1;
            
            //compara o vagao atual com os vagoes seguintes 
            for (int proximo_vagao = vagao_atual + 1; proximo_vagao < numero_vagoes; proximo_vagao++) {
                
                //verifica se o proximo vagao e mais pesado 
                if (pesos_vagoes[proximo_vagao] > pesos_vagoes[vagao_atual]) {
                    if (maior_crescente[proximo_vagao] + 1 > maior_crescente[vagao_atual]) {
                        maior_crescente[vagao_atual] = maior_crescente[proximo_vagao] + 1;
                    }
                }
                
                //verifica se o proximo vagao e mais leve 
                else {
                    if (maior_decrescente[proximo_vagao] + 1 > maior_decrescente[vagao_atual]) {
                        maior_decrescente[vagao_atual] = maior_decrescente[proximo_vagao] + 1;
                    }
                }
            }
            
            //atualiza a maior sequencia crescente e a maior decrescente encontradas 
            if (maior_crescente[vagao_atual] > maior_crescente_geral) {
                maior_crescente_geral = maior_crescente[vagao_atual];
            }
            if (maior_decrescente[vagao_atual] > maior_decrescente_geral) {
                maior_decrescente_geral = maior_decrescente[vagao_atual];
            }
        }
        
        //imprime o tamanho do maior trem 
        if (numero_vagoes == 0) {
            std::cout << 0 << "\n";
        } else {
            std::cout << maior_crescente_geral + maior_decrescente_geral - 1 << "\n";
        }
    }

    return 0;
}