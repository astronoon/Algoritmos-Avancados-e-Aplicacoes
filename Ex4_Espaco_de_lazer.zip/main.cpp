/* Programa em C++ que recebe a grade
de avaliacoes do terreno e encontre a maior 
soma possivel entre todos os sub-retângulos
que podem ser formados usando programacao dinamica*/

#include <iostream>

int main() {

    //leitura do tamanho da matriz
    int lados;
    std::cin >> lados;
    
    //matriz que guarda as notas
    int matriz[200][200];
    
    //leitura das notas da matriz
    for (int linha = 0; linha < lados; linha++) {
        for (int coluna = 0; coluna < lados; coluna++) {
            std::cin >> matriz[linha][coluna];
        }
    }
    
    //guarda a maior soma encontrada
    int melhor_soma = matriz[0][0];
    
    //escolhe a primeira linha do retangulo
    for (int linha_inicio = 0; linha_inicio < lados; linha_inicio++) {
        
        //vetor que guarda a soma das colunas
        int soma_colunas[200];
        
        //inicializa as somas das colunas
        for (int coluna = 0; coluna < lados; coluna++) {
            soma_colunas[coluna] = 0;
        }
        
        //escolhe a ultima linha do retangulo
        for (int linha_fim = linha_inicio; linha_fim < lados; linha_fim++) {
            
            //calcula as somas das colunas
            for (int coluna = 0; coluna < lados; coluna++) {
                soma_colunas[coluna] += matriz[linha_fim][coluna];
            }
            
            //calcula a maior soma entre as colunas
            int soma_atual = 0;
            
            //testa as possibilidades de colunas
            for (int coluna = 0; coluna < lados; coluna++) {
                
                soma_atual += soma_colunas[coluna];
                
                
                if (soma_atual <= melhor_soma) {
                    //mantem a maior soma atual
                } else {
                    //atualiza a soma atual
                melhor_soma = soma_atual;
                }
                
                //se a soma ficou negativa, comeca uma nova soma
                if (soma_atual < 0) {
                    soma_atual = 0;
                }
            }
        }
    }
    
    //imprime a resposta
    std::cout << melhor_soma << std::endl;
    
    return 0;
}
