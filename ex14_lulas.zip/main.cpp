/*programa em c++ com grafos
que diz quantas Lulas
ainda restam no tabuleiro*/

#include <iostream>

//limite maximo do tabuleiro
const int max_tamanho = 105;

//matrizes do tabuleiro e de celulas ja visitadas
char tabuleiro[max_tamanho][max_tamanho];
int visitado[max_tamanho][max_tamanho];
int num_linhas, num_colunas;

//vetores de direcao para andar nas 4 direcoes
int dir_linha[4] = {-1, 1, 0, 0};
int dir_coluna[4] = {0, 0, -1, 1};

//busca em profundidade para explorar toda a lula conectada
void explorar_lula(int linha, int coluna, int &tem_parte_intacta) {
    visitado[linha][coluna] = 1;
    
    //a lula ainda nao foi totalmente encontrada
    if (tabuleiro[linha][coluna] == 'L') {
        tem_parte_intacta = 1;
    }
    
    //verifica os 4 vizinhos
    for (int i = 0; i < 4; i++) {
        int nova_linha = linha + dir_linha[i];
        int nova_coluna = coluna + dir_coluna[i];
        
        //verifica se esta dentro dos limites do tabuleiro
        if (nova_linha >= 0 && nova_linha < num_linhas && nova_coluna >= 0 && nova_coluna < num_colunas) {
            //se ainda nao foi visitado e faz parte da lula
            if (visitado[nova_linha][nova_coluna] == 0 && (tabuleiro[nova_linha][nova_coluna] == 'L' || tabuleiro[nova_linha][nova_coluna] == 'X')) {
                explorar_lula(nova_linha, nova_coluna, tem_parte_intacta);
            }
        }
    }
}

int main() {
    //le as dimensoes do tabuleiro
    if (!(std::cin >> num_linhas >> num_colunas)) {
        return 0;
    }
    
    //le o desenho do tabuleiro e inicializa os visitados
    for (int i = 0; i < num_linhas; i++) {
        std::cin >> tabuleiro[i];
        for (int j = 0; j < num_colunas; j++) {
            visitado[i][j] = 0;
        }
    }
    
    //variaveis que guarda o status da lula
    int lulas_encontradas = 0;
    int lulas_restantes = 0;
    
    //percorre cada celula do tabuleiro
    for (int i = 0; i < num_linhas; i++) {
        for (int j = 0; j < num_colunas; j++) {
            //se achou uma parte de lula ainda nao visitada
            if (visitado[i][j] == 0 && (tabuleiro[i][j] == 'L' || tabuleiro[i][j] == 'X')) {
                int tem_parte_intacta = 0;
                
                //explora toda a lula
                explorar_lula(i, j, tem_parte_intacta);
                
                //classifica se a lula ja foi encontrada ou se ainda resta no jogo
                if (tem_parte_intacta == 1) {
                    lulas_restantes++;
                } else {
                    lulas_encontradas++;
                }
            }
        }
    }
    
    //imprime as lulas encontradas e as restantes
    std::cout << lulas_encontradas << " " << lulas_restantes << "\n";
    
    return 0;
}