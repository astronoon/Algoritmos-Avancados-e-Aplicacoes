/*Programa em C++ que calcula
a satisfacao maxima que podem obter
respeitando as regras do orçamento
e da promocao com programacao dinamica*/

#include <iostream>

// funcao que resolve os casos teste
void resolver_caso() {
    //variaveis
    int itens_disponiveis, orcamento;
    
    //leitura das variveis
    std::cin >> itens_disponiveis >> orcamento;

    //define o limite maximo do orcamento
    int limite_maximo = orcamento + 200;

    //declaracao dos vetores
    int* precos = new int[itens_disponiveis];
    int* satisfacao = new int[itens_disponiveis];
    int* tabela_satisfacao = new int[limite_maximo + 1];

    //guarda os numeros nos vetores
    for (int i = 0; i < itens_disponiveis; ++i) {
        std::cin >> precos[i] >> satisfacao[i];
    }
    
    //inicializacao manual do vetor de satisfacao
    for (int i = 0; i <= limite_maximo; ++i) {
        tabela_satisfacao[i] = -1;
    }
    tabela_satisfacao[0] = 0; 

    //logica de combinacao de valores (mochila)
    for (int i = 0; i < itens_disponiveis; ++i) {
        int p = precos[i];
        int s = satisfacao[i];

        //testando as possibilidades de compra
        for (int dinheiro_gasto = limite_maximo; dinheiro_gasto >= p; --dinheiro_gasto) {
            if (tabela_satisfacao[dinheiro_gasto - p] != -1) {
                //verificacao direta 
                int nova_satisfacao = tabela_satisfacao[dinheiro_gasto - p] + s;
                if (nova_satisfacao > tabela_satisfacao[dinheiro_gasto]) {
                    tabela_satisfacao[dinheiro_gasto] = nova_satisfacao;
                }
            }
        }
    }

    //variavel para guardar o melhor resultado
    int maior_satisfacao = 0;
    
    //procura a maior satisfacao dentro das regras do orcamento
    for (int dinheiro_gasto = 0; dinheiro_gasto <= limite_maximo; ++dinheiro_gasto) {
        if (dinheiro_gasto <= orcamento || (dinheiro_gasto > 2000 && dinheiro_gasto <= limite_maximo)) {
            if (tabela_satisfacao[dinheiro_gasto] > maior_satisfacao) {
                maior_satisfacao = tabela_satisfacao[dinheiro_gasto];
            }
        }
    }

    //exibe o resultado
    std::cout << maior_satisfacao << "\n";

    //liberacao da memoria
    delete[] precos;
    delete[] satisfacao;
    delete[] tabela_satisfacao;
}

int main() {
    
    //variavel de teste
    int casos_teste;
    
    //le os casos de teste e resolve eles
    if (std::cin >> casos_teste) {
        while (casos_teste--) {
            resolver_caso();
        }
    }
    
    return 0;
}