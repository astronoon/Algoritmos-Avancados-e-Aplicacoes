/* Programa em C+ que comanda um robo que
entrega cafes. Esse robo esta na origem de um
plano cartesiano, o codigo imprime o 
resultado final das instruções dadas */

#include <iostream>

//funcao recursiva que calcula o deslocamento da instrucao dada
int deslocamento(int i, int tipo_instrucao[], int indice_referencia[]) {
    switch (tipo_instrucao[i]) {
        //anda para esquerda
        case 0:
            return -1;
        //anda para direita
        case 1:
            return 1;
        //repete uma instrucao
        case 2:
            return deslocamento(indice_referencia[i], tipo_instrucao, indice_referencia);
        //erro
        default:
            return 0;
    }
}

int main() {
    //leitura dos casos de teste
    int casos;
    std::cin >> casos;
    
    //processa os casos de teste
    int caso_atual = 0;
    while (caso_atual < casos) {
        int num_instrucoes;
        std::cin >> num_instrucoes;
        
        //vetor que guarda as instrucoes esquerda, direita, repete
        int tipo_instrucao[1000];
        
        //vetor que guarda instrucao a ser repetida
        int indice_referencia[1000];
        
        //leitura das instrucoes
        for (int i = 0; i < num_instrucoes; i++) {
            char instrucao[20];
            std::cin >> instrucao;
            
            //verificacao da primeira letra pra saber o comando dado
            switch (instrucao[0]) {
                //esquerda, nao tem referencia
                case 'E':
                    tipo_instrucao[i] = 0;
                    indice_referencia[i] = -1;
                    break;
                //direita, nao tem referencia
                case 'D':
                    tipo_instrucao[i] = 1;
                    indice_referencia[i] = -1;
                    break;
                //repete, precisa da referencia da instrucao a repetir
                case 'R':
                    tipo_instrucao[i] = 2;
                    std::cin >> indice_referencia[i];
                    break;
            }
        }
        
        //calculo da posicao final do robo
        int posicao_final = 0;
        for (int i = 0; i < num_instrucoes; i++) {
            //soma de todos os deslocamentos
            posicao_final += deslocamento(i, tipo_instrucao, indice_referencia);
        }
        
        //imprime a posicao final do robo
        std::cout << posicao_final << std::endl;
        caso_atual++;
    }

    return 0;
}