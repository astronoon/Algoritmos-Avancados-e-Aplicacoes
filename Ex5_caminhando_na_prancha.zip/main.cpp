/* Programa em C++ que  calcula o menor
e o maior tempo possivel necessario para 
que todos os prisioneiros caiam na agua
com algoritmo guloso*/

#include <iostream>

int main() {
    //variaveis
    int casos_teste;
    
    //le os casos teste
    std::cin >> casos_teste;
    
    //iteracao para cada caso
    for (int caso = 0; caso < casos_teste; caso++) {
        
        //variaveis
        int compriemento_prencha, prisioneiros;
        
        //le as variaveis
        std::cin >> compriemento_prencha >> prisioneiros;
        
        //menor e maior tempo para todos cairem
        int menor = 0;
        int maior = 0;
        
        //iteracao para ler os prisioneiros
        for (int i = 0; i < prisioneiros; i++) {
            
            //variaveis
            int prisioneiro_atual, perto, longe;
            
            //le o prisioneiro atual
            std::cin >> prisioneiro_atual;
            
            //perto da extremidade esquerda ou perto da direita
            if (prisioneiro_atual < compriemento_prencha - prisioneiro_atual) {
                perto = prisioneiro_atual;
                longe = compriemento_prencha - prisioneiro_atual;
            } else {
                perto = compriemento_prencha - prisioneiro_atual;
                longe = prisioneiro_atual;
            }
            
            //ultimo a cair do menor
            if (perto > menor) {
                menor = perto;
            }
            
            //ultimo a cair do maior
            if (longe > maior) {
                maior = longe;
            }
        }
        
        //imprime a saida
        std::cout << menor << " " << maior << "\n";
    }
    return 0;
}