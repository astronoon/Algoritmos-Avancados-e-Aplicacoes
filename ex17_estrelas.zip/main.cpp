/*programa em c++ com geometria
computacional para identificar 
os vertices do fecho convexo
almejado*/

#include <iostream>

//limite maximo de estrelas
const int max_estrelas = 100005;

struct ponto {
    long long x;
    long long y;
};

//variaveis de geometria das estrelas
ponto estrelas[max_estrelas];
ponto auxiliar[max_estrelas];
ponto fecho[max_estrelas * 2];

//verifica se o ponto a vem antes do ponto b
int eh_menor(ponto a, ponto b) {
    if (a.x != b.x) {
        if (a.x < b.x) {
            return 1;
        }
        return 0;
    }
    if (a.y < b.y) {
        return 1;
    }
    return 0;
}

//junta as duas metades ordenadas (merge sort)
void intercalar(int inicio, int meio, int fim) {
    int i = inicio;
    int j = meio + 1;
    int k = inicio;

    while (i <= meio && j <= fim) {
        if (eh_menor(estrelas[i], estrelas[j]) == 1) {
            auxiliar[k] = estrelas[i];
            i++;
        } else {
            auxiliar[k] = estrelas[j];
            j++;
        }
        k++;
    }

    while (i <= meio) {
        auxiliar[k] = estrelas[i];
        i++;
        k++;
    }

    while (j <= fim) {
        auxiliar[k] = estrelas[j];
        j++;
        k++;
    }

    for (int p = inicio; p <= fim; p++) {
        estrelas[p] = auxiliar[p];
    }
}

//ordena os pontos por x e depois por y
void ordenar_pontos(int inicio, int fim) {
    if (inicio < fim) {
        int meio = inicio + (fim - inicio) / 2;
        ordenar_pontos(inicio, meio);
        ordenar_pontos(meio + 1, fim);
        intercalar(inicio, meio, fim);
    }
}

//produto vetorial
long long produto_vetorial(ponto o, ponto a, ponto b) {
    return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
}

int main() {
    //variavel dos casos teste
    int numero_casos;

    //le a quantidade de casos de teste
    if (!(std::cin >> numero_casos)) {
        return 0;
    }

    for (int caso = 1; caso <= numero_casos; caso++) {
        int num_estrelas;
        std::cin >> num_estrelas;
        
        for (int i = 0; i < num_estrelas; i++) {
            std::cin >> estrelas[i].x >> estrelas[i].y;
        }
        
        //ordena todas as estrelas
        ordenar_pontos(0, num_estrelas - 1);
        
        //remove pontos duplicados consecutivos
        int qtd_unicos = 0;
        for (int i = 0; i < num_estrelas; i++) {
            if (i == 0 || estrelas[i].x != estrelas[i - 1].x || estrelas[i].y != estrelas[i - 1].y) {
                estrelas[qtd_unicos] = estrelas[i];
                qtd_unicos++;
            }
        }
        
        int k = 0;
        
        //caso especial: apenas 1 ponto distinto
        if (qtd_unicos == 1) {
            fecho[0] = estrelas[0];
            k = 1;
        } else {
            //constroi a parte inferior do fecho
            for (int i = 0; i < qtd_unicos; i++) {
                while (k >= 2 && produto_vetorial(fecho[k - 2], fecho[k - 1], estrelas[i]) <= 0) {
                    k--;
                }
                fecho[k] = estrelas[i];
                k++;
            }
            
            //constroi a parte superior do fecho
            int limite_inferior = k + 1;
            for (int i = qtd_unicos - 2; i >= 0; i--) {
                while (k >= limite_inferior && produto_vetorial(fecho[k - 2], fecho[k - 1], estrelas[i]) <= 0) {
                    k--;
                }
                fecho[k] = estrelas[i];
                k++;
            }
            
            //remove o ultimo ponto
            k--;
        }
        
        //imprime a saida
        std::cout << "Caso " << caso << ":\n";
        std::cout << "Tamanho do fecho: " << k << "\n";
        std::cout << "Estrelas: ";
        for (int i = 0; i < k; i++) {
            if (i > 0) {
                std::cout << ",";
            }
            std::cout << "(" << fecho[i].x << "," << fecho[i].y << ")";
        }
        
        std::cout << "\n";
        
        if (caso < numero_casos) {
            std::cout << "\n";
        }
    }

    return 0;
}