/*Programa em C++ que determina
a quantidade máxima de sorvete que
pode ser escoada pela malha logística
sem perdas com o algoritmo de Ford-Fulkerson*/


#include <iostream>

#define MAX_NOS 205
#define INFINITO 1000000000

//variaveis globais usadas para representar a rede e os caminhos
int capacidade[MAX_NOS][MAX_NOS];
int adjacencia[MAX_NOS][MAX_NOS];
int tamanho_adj[MAX_NOS];
int pai[MAX_NOS];
int visitado[MAX_NOS];
int fila[MAX_NOS];

//retorna o menor numero entre duas opcoes
int obter_minimo(int a, int b) {
    if (a < b) {
        return a;
    } else {
        return b;
    }
}

//adiciona uma rota entre dois pontos e prepara o caminho de volta
void adicionar_aresta(int u, int v, int cap) {
    capacidade[u][v] += cap;
    adjacencia[u][tamanho_adj[u]++] = v;
    adjacencia[v][tamanho_adj[v]++] = u;
}

//busca em largura nos caminhos
int busca_largura(int origem, int destino_final, int total_nos) {
    //zera os rastros de caminhos anteriores
    for (int i = 0; i < total_nos; ++i) {
        visitado[i] = 0;
        pai[i] = -1;
    }
    
    //configura o inicio da fila com o ponto de origem
    int indice_frente = 0;
    int indice_tras = 0;
    fila[indice_tras++] = origem;
    visitado[origem] = 1;
    
    //enquanto tiver locais na fila para explorar
    while (indice_frente < indice_tras) {
        int u = fila[indice_frente++]; 
        
        //verifica todos os vizinhos do local atual
        for (int i = 0; i < tamanho_adj[u]; ++i) {
            int v = adjacencia[u][i];
            
            //se o vizinho ainda não foi visitado e cabe mais sorvete
            if (visitado[v] == 0 && capacidade[u][v] > 0) {
                pai[v] = u;
                visitado[v] = 1;
                
                //se chegou no destino final, encerra a busca com sucesso
                if (v == destino_final) {
                    return 1; 
                }
                
                //coloca o vizinho na fila para continuar procurando
                fila[indice_tras++] = v; 
            }
        }
    }
    
    return 0;
}

//algoritmo de ford-fulkerson (edmonds-karp)
int calcular_fluxo_maximo(int origem, int destino_final, int total_nos) {
    int fluxo_maximo = 0;
    
    //enquanto existir um caminho valido da origem ao destino
    while (busca_largura(origem, destino_final, total_nos) == 1) {
        int fluxo_caminho = INFINITO;
        int atual = destino_final;
        
        //refaz o caminho de traz para frente
        while (atual != origem) {
            fluxo_caminho = obter_minimo(fluxo_caminho, capacidade[pai[atual]][atual]);
            atual = pai[atual];
        }
        
        //atualiza as capacidades ocupando o espaço encontrado no caminho
        int v = destino_final;
        while (v != origem) {
            int u = pai[v];
            capacidade[u][v] -= fluxo_caminho;
            capacidade[v][u] += fluxo_caminho;
            v = pai[v];
        }
        
        //soma a quantidade transportada neste caminho ao total geral
        fluxo_maximo += fluxo_caminho;
    }
    
    return fluxo_maximo;
}

int main() {
    //variavel de caso teste
    int casos_teste;
    
    //encerra se nao conseguir ler os casos de teste
    if (!(std::cin >> casos_teste)) {
        return 0;
    }
    
    //processa cada um dos cenarios
    while (casos_teste--) {
        int n;
        std::cin >> n;
        
        int total_nos = 2 * n + 2;
        int super_origem = 0;
        int super_destino = total_nos - 1;
        
        //limpa os dados do teste anterior
        for (int i = 0; i < total_nos; ++i) {
            tamanho_adj[i] = 0;
            for (int j = 0; j < total_nos; ++j) {
                capacidade[i][j] = 0;
            }
        }
        
        int refrigeradores[105];
        for (int i = 0; i < n; ++i) {
            std::cin >> refrigeradores[i];
        }
        
        int m;
        std::cin >> m;
        
        //cria uma entrada e saida para cada refrigerador, definindo o limite dele
        for (int i = 1; i <= n; ++i) {
            int u_entrada = i;
            int u_saida = i + n;
            adicionar_aresta(u_entrada, u_saida, refrigeradores[i - 1]);
        }
        
        //le e conecta as rotas entre os refrigeradores
        for (int i = 0; i < m; ++i) {
            int u, v, capacidade_aresta;
            std::cin >> u >> v >> capacidade_aresta;
            int u_saida = u + n;
            int v_entrada = v;
            adicionar_aresta(u_saida, v_entrada, capacidade_aresta);
        }
        
        int b, d;
        std::cin >> b >> d;
        
        //liga a fonte de sorvete aos pontos de partida da malha
        for (int i = 0; i < b; ++i) {
            int indice_entrada;
            std::cin >> indice_entrada;
            adicionar_aresta(super_origem, indice_entrada, INFINITO);
        }
        
        //liga os destinos finais da malha ao ponto de coleta
        for (int i = 0; i < d; ++i) {
            int indice_destino;
            std::cin >> indice_destino;
            int destino_saida = indice_destino + n;
            adicionar_aresta(destino_saida, super_destino, INFINITO);
        }
        
        //imprime a resposta
        std::cout << calcular_fluxo_maximo(super_origem, super_destino, total_nos) << "\n";
    }
    
    return 0;
}
