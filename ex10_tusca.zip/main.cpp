/*Programa em C++ que encontra
uma ordem para beber seguindo
as regras citadas com grafos*/

#include <iostream>
#include <string>

int main() {
    //variaveis globais do caso de teste
    int quantidade_bebidas, quantidade_regras;
    
    //leitura da quantidade
    while (std::cin >> quantidade_bebidas) {
        //nomes das bebidas
        std::string nomes_bebidas[105];
        //contador de dependencias
        int dependencias[105];
        //matriz de grafo
        int eh_pre_requisito[105][105];
        //marca as q ja foram
        int ja_consumida[105];
        
        //inicializa as variaveis
        for (int i = 0; i < quantidade_bebidas; ++i) {
            std::cin >> nomes_bebidas[i];
            dependencias[i] = 0;
            ja_consumida[i] = 0;
            for (int j = 0; j < quantidade_bebidas; ++j) {
                eh_pre_requisito[i][j] = 0;
            }
        }
        
        //le as regras
        std::cin >> quantidade_regras;
        
        //monta as dependencias
        for (int i = 0; i < quantidade_regras; ++i) {
            std::string bebida_menor_teor, bebida_maior_teor;
            std::cin >> bebida_menor_teor >> bebida_maior_teor;
            
            int indice_menor_teor = -1, indice_maior_teor = -1;
            
            //busca o indice
            for (int j = 0; j < quantidade_bebidas; ++j) {
                if (nomes_bebidas[j] == bebida_menor_teor) indice_menor_teor = j;
                if (nomes_bebidas[j] == bebida_maior_teor) indice_maior_teor = j;
            }
            
            //define q a de menor teor vem primeiro
            if (indice_menor_teor != -1 && indice_maior_teor != -1) {
                eh_pre_requisito[indice_menor_teor][indice_maior_teor] = 1;
                dependencias[indice_maior_teor]++;
            }
        }
        
        //realiza a escolha da ordem
        for (int etapa = 0; etapa < quantidade_bebidas; ++etapa) {
            int indice_escolhida = -1;
            
            //busca a bebida disponivel na ordem alfabetica
            for (int i = 0; i < quantidade_bebidas; ++i) {
                if (ja_consumida[i] == 0 && dependencias[i] == 0) {
                    if (indice_escolhida == -1 || nomes_bebidas[i] < nomes_bebidas[indice_escolhida]) {
                        indice_escolhida = i;
                    }
                }
            }
            
            //marca como consumida
            ja_consumida[indice_escolhida] = 1;
            
            //imprime o nome
            std::cout << nomes_bebidas[indice_escolhida];
            if (etapa < quantidade_bebidas - 1) {
                std::cout << " ";
            } else {
                //ponto final
                std::cout << ".\n";
            }
            
            //libera as q dependiam dessa
            for (int i = 0; i < quantidade_bebidas; ++i) {
                if (eh_pre_requisito[indice_escolhida][i] == 1) {
                    dependencias[i]--;
                }
            }
        }
    }

    return 0;
}