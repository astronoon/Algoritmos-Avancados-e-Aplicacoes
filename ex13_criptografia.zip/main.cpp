/*programa em c++ que
automatiza a descriptografia*/

#include <iostream>
#include <cstring>

//estrutura para guardar dados de cada caractere
struct info_caractere {
    char caractere;
    int frequencia;
    int primeira_posicao;
};

//funcao simples para ordenar
void ordenar_frequencias(info_caractere vetor_info[], int tamanho) {
    for (int i = 0; i < tamanho - 1; i++) {
        for (int j = 0; j < tamanho - i - 1; j++) {
            bool houve_troca = false;
            
            //primeiro criterio: maior frequencia
            if (vetor_info[j].frequencia < vetor_info[j + 1].frequencia) {
                houve_troca = true;
            }
            //segundo criterio (desempate): menor posicao de aparicao
            else if (vetor_info[j].frequencia == vetor_info[j + 1].frequencia && vetor_info[j].primeira_posicao > vetor_info[j + 1].primeira_posicao) {
                houve_troca = true;
            }
            
            if (houve_troca) {
                info_caractere variavel_temporaria = vetor_info[j];
                vetor_info[j] = vetor_info[j + 1];
                vetor_info[j + 1] = variavel_temporaria;
            }
        }
    }
}

//verifica se o caractere e valido para a contagem
bool caractere_eh_valido(char caractere_teste) {
    return (caractere_teste >= 'a' && caractere_teste <= 'z') || (caractere_teste >= '0' && caractere_teste <= '9');
}

//limpa problemas de quebra de linha
void limpar_quebra_linha(char* texto) {
    int tamanho = std::strlen(texto);
    while (tamanho > 0 && (texto[tamanho - 1] == '\r' || texto[tamanho - 1] == '\n')) {
        texto[tamanho - 1] = '\0';
        tamanho--;
    }
}

int main() {
    //variavel de teste
    int numero_casos;

    //le a quantidade de casos de teste
    if (!(std::cin >> numero_casos)) {
        return 0;
    }

    char texto_referencia[10050];
    char texto_cifrado[10050];

    while (numero_casos--) {
        //pula a quebra de linha e linhas em branco ate achar o texto de referencia real
        do {
            //evita laco infinito no fim da entrada
            if (!std::cin.getline(texto_referencia, 10050)) {
                return 0;
            }
            limpar_quebra_linha(texto_referencia);
        } while (std::strlen(texto_referencia) == 0);
        
        //le o texto cifrado e limpa a quebra de linha invisivel
        if (!std::cin.getline(texto_cifrado, 10050)) {
            texto_cifrado[0] = '\0';
        }
        limpar_quebra_linha(texto_cifrado);
        
        info_caractere info_referencia[256];
        info_caractere info_cifrado[256];
        
        //inicializa os dados
        for (int i = 0; i < 256; i++) {
            info_referencia[i].caractere = (char)i;
            info_referencia[i].frequencia = 0;
            info_referencia[i].primeira_posicao = 100000;
            
            info_cifrado[i].caractere = (char)i;
            info_cifrado[i].frequencia = 0;
            info_cifrado[i].primeira_posicao = 100000;
        }
        
        //conta frequencias do texto de referencia
        int tamanho_referencia = std::strlen(texto_referencia);
        for (int i = 0; i < tamanho_referencia; i++) {
            char caractere_atual = texto_referencia[i];
            if (caractere_eh_valido(caractere_atual)) {
                info_referencia[(unsigned char)caractere_atual].frequencia++;
                if (info_referencia[(unsigned char)caractere_atual].primeira_posicao == 100000) {
                    info_referencia[(unsigned char)caractere_atual].primeira_posicao = i;
                }
            }
        }
        
        //conta frequencias do texto cifrado
        int tamanho_cifrado = std::strlen(texto_cifrado);
        for (int i = 0; i < tamanho_cifrado; i++) {
            char caractere_atual = texto_cifrado[i];
            if (caractere_eh_valido(caractere_atual)) {
                info_cifrado[(unsigned char)caractere_atual].frequencia++;
                if (info_cifrado[(unsigned char)caractere_atual].primeira_posicao == 100000) {
                    info_cifrado[(unsigned char)caractere_atual].primeira_posicao = i;
                }
            }
        }
        
        //extrai apenas os validos que apareceram na referencia
        info_caractere validos_referencia[40];
        int quantidade_referencia = 0;
        for (int i = 0; i < 256; i++) {
            if (caractere_eh_valido((char)i) && info_referencia[i].frequencia > 0) {
                validos_referencia[quantidade_referencia++] = info_referencia[i];
            }
        }
        
        //extrai apenas os validos que apareceram no cifrado
        info_caractere validos_cifrado[40];
        int quantidade_cifrado = 0;
        for (int i = 0; i < 256; i++) {
            if (caractere_eh_valido((char)i) && info_cifrado[i].frequencia > 0) {
                validos_cifrado[quantidade_cifrado++] = info_cifrado[i];
            }
        }
        
        //ordena com o desempate cronologico
        ordenar_frequencias(validos_referencia, quantidade_referencia);
        ordenar_frequencias(validos_cifrado, quantidade_cifrado);
        
        //mapa de substituicao do cifrado para a referencia
        char mapa_substituicao[256];
        for (int i = 0; i < 256; i++) {
            mapa_substituicao[i] = (char)i;
        }
        
        int limite_mapeamento = quantidade_referencia;
        if (quantidade_cifrado < quantidade_referencia) {
            limite_mapeamento = quantidade_cifrado;
        }
        
        for (int i = 0; i < limite_mapeamento; i++) {
            mapa_substituicao[(unsigned char)validos_cifrado[i].caractere] = validos_referencia[i].caractere;
        }
        
        //imprime a mensagem traduzida
        for (int i = 0; i < tamanho_cifrado; i++) {
            char caractere_atual = texto_cifrado[i];
            if (caractere_eh_valido(caractere_atual)) {
                std::cout << mapa_substituicao[(unsigned char)caractere_atual];
            } else {
                std::cout << caractere_atual;
            }
        }
        
        //quebra de linha + linha em branco apos cada caso
        std::cout << "\n\n";
    }

    return 0;
}