/*programa em c++ que usa teoria
dos numeros para encontrar uma
sequencia crescente de numeros primos
cuja soma seja exatamente a 
concatenacao dessa sequencia*/

#include <cstdio>

//funcao para verificar se um numero e primo
int eh_primo(int valor) {
    //verifica se e menor ou igual a um
    if (valor <= 1) {
        return 0;
    }
    
    //o dois e o unico numero primo par
    if (valor == 2) {
        return 1;
    }
    
    //elimina os outros numeros pares
    if (valor % 2 == 0) {
        return 0;
    }
    
    //verifica os divisores impares ate a raiz quadrada
    for (int divisor = 3; divisor * divisor <= valor; divisor += 2) {
        if (valor % divisor == 0) {
            return 0;
        }
    }
    return 1;
}

int main() {
    //variavel dos casos teste
    int quantidade_casos;
    
    //le a quantidade de casos de teste
    if (scanf("%d", &quantidade_casos) == 1) {
        
        //resolve todos os casos de teste
        while (quantidade_casos--) {
            int numero_alvo;
            
            //le o numero alvo
            scanf("%d", &numero_alvo);
            
            int resposta_encontrada = 0;
            
            //tenta formar com dois primos verificando primeiro se o menor e o numero dois
            if (numero_alvo > 2 && eh_primo(numero_alvo - 2)) {
                //imprime a concatenacao do dois com o restante
                printf("2%d\n", numero_alvo - 2);
                resposta_encontrada = 1;
            } 
            //tenta formar com dois primos impares
            else {
                for (int primo_1 = 3; primo_1 <= numero_alvo / 2; primo_1 += 2) {
                    int primo_2 = numero_alvo - primo_1;
                    
                    //verifica se os dois sao primos e o primeiro e estritamente menor
                    if (primo_1 < primo_2 && eh_primo(primo_1) && eh_primo(primo_2)) {
                        //imprime a concatenacao dos dois primos
                        printf("%d%d\n", primo_1, primo_2);
                        resposta_encontrada = 1;
                        break;
                    }
                }
            }
            
            //se nao foi possivel com dois primos tenta com tres primos
            if (!resposta_encontrada) {
                //se chegou aqui com certeza os 3 primos precisam ser impares
                for (int primo_1 = 3; primo_1 <= numero_alvo / 3 && !resposta_encontrada; primo_1 += 2) {
                    if (eh_primo(primo_1)) {
                        //calcula a soma restante
                        int soma_restante = numero_alvo - primo_1;
                        
                        //busca o segundo primo
                        for (int primo_2 = primo_1 + 2; primo_2 <= soma_restante / 2; primo_2 += 2) {
                            if (eh_primo(primo_2)) {
                                int primo_3 = soma_restante - primo_2;
                                
                                //verifica se o terceiro e valido e maior que o segundo
                                if (primo_2 < primo_3 && eh_primo(primo_3)) {
                                    //imprime a concatenacao dos tres primos
                                    printf("%d%d%d\n", primo_1, primo_2, primo_3);
                                    resposta_encontrada = 1;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return 0;
}