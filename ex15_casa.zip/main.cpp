/*programa em c++ com divisao
e conquista para economizar tinta*/

#include <iostream>

//limite maximo para latas e cores
const int max_elementos = 10005;
int tamanhos_latas[max_elementos];
int vetor_auxiliar[max_elementos];

//junta as duas metades ordenadas
void intercalar(int inicio, int meio, int fim) {
    int i = inicio;
    int j = meio + 1;
    int k = inicio;
    
    while (i <= meio && j <= fim) {
        if (tamanhos_latas[i] <= tamanhos_latas[j]) {
            vetor_auxiliar[k] = tamanhos_latas[i];
            i++;
        } else {
            vetor_auxiliar[k] = tamanhos_latas[j];
            j++;
        }
        k++;
    }
    
    //copia o que sobrou da primeira metade
    while (i <= meio) {
        vetor_auxiliar[k] = tamanhos_latas[i];
        i++;
        k++;
    }
    
    //copia o que sobrou da segunda metade
    while (j <= fim) {
        vetor_auxiliar[k] = tamanhos_latas[j];
        j++;
        k++;
    }
    
    //devolve os valores ordenados para o vetor original
    for (int p = inicio; p <= fim; p++) {
        tamanhos_latas[p] = vetor_auxiliar[p];
    }
}

//algoritmo de divisao e conquista para ordenar as latas
void merge_sort(int inicio, int fim) {
    if (inicio < fim) {
        int meio = inicio + (fim - inicio) / 2;
        merge_sort(inicio, meio);
        merge_sort(meio + 1, fim);
        intercalar(inicio, meio, fim);
    }
}

//busca binaria para achar a menor lata maior ou igual ao necessario
int buscar_menor_lata(int num_latas, int tinta_necessaria) {
    int inicio = 0;
    int fim = num_latas - 1;
    int melhor_lata = -1;
    
    while (inicio <= fim) {
        int meio = inicio + (fim - inicio) / 2;
        //tenta achar uma lata ainda menor na esquerda
        if (tamanhos_latas[meio] >= tinta_necessaria) {
            melhor_lata = tamanhos_latas[meio];
            fim = meio - 1; 
        } else {
            //precisa de uma lata maior na direita
            inicio = meio + 1;
        }
    }
    
    return melhor_lata;
}

int main() {
    //variavel de casos teste
    int numero_casos;
    
    //le a quantidade de casos de teste
    if (!(std::cin >> numero_casos)) {
        return 0;
    }
    
    while (numero_casos--) {
        int num_latas, num_cores;
        std::cin >> num_latas >> num_cores;
        
        //le os tamanhos disponiveis na loja
        for (int i = 0; i < num_latas; i++) {
            std::cin >> tamanhos_latas[i];
        }
        
        //ordena as latas usando divisao e conquista
        merge_sort(0, num_latas - 1);
        
        long long desperdicio_total = 0;
        
        //para cada cor, busca a melhor lata e soma o que sobrar
        for (int i = 0; i < num_cores; i++) {
            int tinta_necessaria;
            std::cin >> tinta_necessaria;
            
            int lata_escolhida = buscar_menor_lata(num_latas, tinta_necessaria);
            
            if (lata_escolhida != -1) {
                desperdicio_total += (lata_escolhida - tinta_necessaria);
            }
        }
        
        //imprime o desperdicio total do caso de teste
        std::cout << desperdicio_total << "\n";
    }
    
    return 0;
}