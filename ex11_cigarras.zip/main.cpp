/*Programa em C++ que determina
o maior ciclo de vida entre as espécies 
de cigarra que emergem nesse ano com
teoria dos numeros*/


#include <iostream>

//retorna o maior fator primo do ano
long long encontrar_maior_ciclo_vida(long long ano_restante) {
    long long maior_ciclo_vida = -1;

    //extrai fatores pares
    while (ano_restante % 2 == 0) {
        maior_ciclo_vida = 2;
        ano_restante /= 2;
    }

    //extrai fatores impares ate a raiz quadrada
    long long divisor_atual = 3;
    while (divisor_atual <= ano_restante / divisor_atual) {
        while (ano_restante % divisor_atual == 0) {
            maior_ciclo_vida = divisor_atual;
            ano_restante /= divisor_atual;
        }
        divisor_atual += 2;
    }

    //se o restante for primo e maior que 2 iguala
    if (ano_restante > 2) {
        maior_ciclo_vida = ano_restante;
    }

    return maior_ciclo_vida;
}

int main() {
    //variavel dos casos teste
    int quantidade_expedicoes;

    //processa cada expedicao
    std::cin >> quantidade_expedicoes;
    for (int iteracao = 0; iteracao < quantidade_expedicoes; iteracao++) {
        long long ano_analisado;
        std::cin >> ano_analisado;
        std::cout << encontrar_maior_ciclo_vida(ano_analisado) << "\n";
    }

    return 0;
}
