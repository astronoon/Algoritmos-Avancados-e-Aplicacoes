/*programa em c++ com programacao
dinamica que diz o peso final que
link ira levantar*/

#include <iostream>

//limite maximo para pesos e anilhas
const int max_peso = 20005;
const int max_anilhas = 1005;

//vetor da programacao dinamica
int possivel[max_peso];
int anilhas[max_anilhas];

//funcao auxiliar para pegar o valor absoluto
int valor_absoluto(int x) {
    if (x < 0) {
        return -x;
    }
    return x;
}

int main() {
    //variavel dos casos teste
    int numero_casos;
    
    //le a quantidade de casos de teste
    if (!(std::cin >> numero_casos)) {
        return 0;
    }
    
    while (numero_casos--) {
        int num_anilhas, peso_desejado;
        std::cin >> num_anilhas >> peso_desejado;
        
        //le o peso de cada anilha
        for (int i = 0; i < num_anilhas; i++) {
            std::cin >> anilhas[i];
        }
        
        //define o limite superior de busca
        int limite_busca = peso_desejado * 2;
        if (limite_busca >= max_peso) {
            limite_busca = max_peso - 1;
        }
        
        //inicializa a tabela da programacao dinamica com 0
        for (int i = 0; i <= limite_busca; i++) {
            possivel[i] = 0;
        }
        
        //barra vazia
        possivel[0] = 1;
        
        //preenche a tabela testando cada anilha
        for (int i = 0; i < num_anilhas; i++) {
            int peso_atual = anilhas[i];
            for (int p = limite_busca; p >= peso_atual; p--) {
                if (possivel[p - peso_atual] == 1) {
                    possivel[p] = 1;
                }
            }
        }
        
        int melhor_peso = 0;
        int menor_diferenca = max_peso;
        
        //procura o peso montavel mais proximo do desejado
        for (int p = 0; p <= limite_busca; p++) {
            if (possivel[p] == 1) {
                int diferenca_atual = valor_absoluto(p - peso_desejado);
                
                //se achou uma diferenca menor, atualiza
                if (diferenca_atual < menor_diferenca) {
                    menor_diferenca = diferenca_atual;
                    melhor_peso = p;
                } 
                //se empatou na distancia, escolhe o maior peso
                else if (diferenca_atual == menor_diferenca && p > melhor_peso) {
                    melhor_peso = p;
                }
            }
        }
        
        //imprime o peso final escolhido
        std::cout << melhor_peso << "\n";
    }
    
    return 0;
}