/* Programa em C++ que
encontrar o preco que produza 
o menor numero de pessoas
irritadas com divisao e conquista */

#include <iostream>

const int MAX = 100000;

//junta duas partes ordenadas
void mesclar(int* vetor, int inicio, int meio, int fim) {
    int esquerda[MAX];
    int direita[MAX];

    int tam_esq = meio - inicio + 1;
    int tam_dir = fim - meio;

    for (int i = 0; i < tam_esq; i++) {
        esquerda[i] = vetor[inicio + i];
    }

    for (int i = 0; i < tam_dir; i++) {
        direita[i] = vetor[meio + 1 + i];
    }

    int i = 0;
    int j = 0;
    int k = inicio;

    while (i < tam_esq && j < tam_dir) {
        if (esquerda[i] <= direita[j]) {
            vetor[k] = esquerda[i];
            i++;
        } else {
            vetor[k] = direita[j];
            j++;
            
        }
        
        k++;
    }

    while (i < tam_esq) {
        vetor[k] = esquerda[i];
        i++;
        k++;
    }

    while (j < tam_dir) {
        vetor[k] = direita[j];
        j++;
        k++;
    }
}

//ordena o vetor
void merge_sort(int* vetor, int inicio, int fim) {
    if (inicio >= fim) {
        return;
    }

    int meio = inicio + (fim - inicio) / 2;

    merge_sort(vetor, inicio, meio);
    merge_sort(vetor, meio + 1, fim);

    mesclar(vetor, inicio, meio, fim);
}

//conta os elementos menores que o valor
int conta_menores(const int* vetor, int inicio, int fim, int valor_alvo) {
    
    if (inicio > fim) {
        return inicio;
    }

    int meio = inicio + (fim - inicio) / 2;

    if (vetor[meio] < valor_alvo) {
        return conta_menores(vetor, meio + 1, fim, valor_alvo);
    } else {
        return conta_menores(vetor, inicio, meio - 1, valor_alvo);
    }
}

//resolve um caso
void resolver_caso() {
    int qtd_aventureiros;
    int qtd_clientes;

    std::cin >> qtd_aventureiros >> qtd_clientes;

    int aventureiros[MAX];
    int clientes[MAX];

    //le os precos dos aventureiros
    for (int i = 0; i < qtd_aventureiros; i++) {
        std::cin >> aventureiros[i];
    }

    //le os precos dos clientes
    for (int i = 0; i < qtd_clientes; i++) {
        std::cin >> clientes[i];
    }

    //ordena os vetores
    if (qtd_aventureiros > 0) {
        merge_sort(aventureiros, 0, qtd_aventureiros - 1);
    }

    if (qtd_clientes > 0) {
        merge_sort(clientes, 0, qtd_clientes - 1);
    }

    //comeca com preco zero
    int melhor_preco = 0;
    int min_irritados = qtd_aventureiros;

    //testa os precos dos aventureiros
    for (int i = 0; i < qtd_aventureiros; i++) {

        //ignora precos repetidos
        if (i == qtd_aventureiros - 1 || aventureiros[i] != aventureiros[i + 1]) {
            
            int preco_atual = aventureiros[i];
            
            //conta os aventureiros irritados
            int aventureiros_irritados = qtd_aventureiros - (i + 1);
            
            //conta os clientes irritados
            int clientes_irritados = 0;
            
            if (qtd_clientes > 0) {
                clientes_irritados = conta_menores(clientes,0,qtd_clientes - 1,preco_atual);
            }
            
            //soma os irritados
            int total_irritados = aventureiros_irritados + clientes_irritados;
                
            //atualiza a melhor resposta
            if (total_irritados < min_irritados) {
                min_irritados = total_irritados;
                melhor_preco = preco_atual;
                
            } else if (total_irritados == min_irritados && preco_atual < melhor_preco) {
                melhor_preco = preco_atual;
            }
        }
    }

    //imprime o resultado
    std::cout << melhor_preco << " " << min_irritados << "\n";
}

int main() {

    //variaveis
    int casos_teste;

    //le a quantidade de casos
    std::cin >> casos_teste;

    //resolve cada caso
    while (casos_teste > 0) {
        resolver_caso();
        casos_teste--;
    }

    return 0;
}