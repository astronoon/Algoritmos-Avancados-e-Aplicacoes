/*Programa em C++ que distribui os artistas
entre os dias do festival, mantendo a ordem 
original das apresentações e minimizando
a duração total do dia mais longo com
divisão e conquista*/

#include <iostream>

//funcao de divisao e conquista
int divide_conquista(int quantidade_artistas, int quantidade_dias, int soma_duracoes[], int memoria[][31]) {
    
    //caso base: um dia
    if (quantidade_dias == 1) {
        return soma_duracoes[quantidade_artistas];
    }
    
    //caso base: um artista por dia
    if (quantidade_artistas == quantidade_dias) {
        int maior_duracao = 0;
        
        for (int artista = 1; artista <= quantidade_artistas; artista++) {
            int duracao = soma_duracoes[artista] - soma_duracoes[artista - 1];
            
            if (duracao > maior_duracao) {
                maior_duracao = duracao;
            }
        }
        
        return maior_duracao;
    }
    
    //verifica se ja foi calculado
    if (memoria[quantidade_artistas][quantidade_dias] != -1) {
        return memoria[quantidade_artistas][quantidade_dias];
    }
    
    //valor inicial grande
    int melhor_tempo = 1000000;
    
    //testa os cortes possiveis
    for (int corte = quantidade_dias - 1; corte < quantidade_artistas; corte++) {
        
        //calcula a duracao do ultimo dia
        int duracao_ultimo_dia = soma_duracoes[quantidade_artistas] - soma_duracoes[corte];
        
        //calcula recursivamente os dias anteriores
        int maior_tempo = divide_conquista(corte, quantidade_dias - 1, soma_duracoes, memoria);
        
        //maior dia entre os anteriores e o ultimo
        if (duracao_ultimo_dia > maior_tempo) {
            maior_tempo = duracao_ultimo_dia;
        }
        
        //atualiza com a melhor solucao
        if (maior_tempo < melhor_tempo) {
            melhor_tempo = maior_tempo;
        }
    }
    
    //guarda o resultado
    memoria[quantidade_artistas][quantidade_dias] = melhor_tempo;
    
    return melhor_tempo;
}

int main() {

    //leitura dos casos de teste
    int casos;
    std::cin >> casos;
    
    //processa os casos de teste
    for (int caso_atual = 1; caso_atual <= casos; caso_atual++) {
        
        //leitura da quantidade de artistas e dias
        int quantidade_artistas;
        int quantidade_dias;
        
        std::cin >> quantidade_artistas >> quantidade_dias;
        
        //vetor que guarda a duracao dos shows
        int duracao_artista[31];
        
        //vetor que guarda as somas acumuladas
        int soma_duracoes[31];
        soma_duracoes[0] = 0;
        
        //memoria dos resultados
        int memoria[31][31];
        
        for (int artista = 0; artista < 31; artista++) {
            for (int dia = 0; dia < 31; dia++) {
                memoria[artista][dia] = -1;
            }
        }
        
        //leitura das duracoes
        for (int artista = 1; artista <= quantidade_artistas; artista++) {
            std::cin >> duracao_artista[artista];
            
            soma_duracoes[artista] = soma_duracoes[artista - 1] + duracao_artista[artista];
        }
        
        //calcula a melhor distribuicao
        int melhor_tempo = divide_conquista(
            quantidade_artistas,
            quantidade_dias,
            soma_duracoes,
            memoria
        );
        
        //imprime a resposta
        std::cout << "Caso " << caso_atual << ": "
                  << melhor_tempo
                  << std::endl;
    }
    
    return 0;
}